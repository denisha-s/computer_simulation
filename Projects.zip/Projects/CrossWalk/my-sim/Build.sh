#
# Simply set execute mode on SIM
#
chmod +x SIM
